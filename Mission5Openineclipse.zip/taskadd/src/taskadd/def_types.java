package taskadd;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import java.awt.BorderLayout;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class def_types {

	 JFrame frmDefineTaskTypes;
	public static JTable tbl_def;
	private JTextField txt_regtype;

	/**
	 * Launch the application.
	 */
	
	
	
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					def_types window = new def_types();
//					window.frmDefineTaskTypes.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 */
	public def_types() {
		initialize();
	}
	
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmDefineTaskTypes = new JFrame();
		frmDefineTaskTypes.setTitle("Define task types");
		frmDefineTaskTypes.setBounds(100, 100, 450, 300);
		frmDefineTaskTypes.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmDefineTaskTypes.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(21, 92, 403, 158);
		frmDefineTaskTypes.getContentPane().add(scrollPane);
		
		tbl_def = new JTable();
		tbl_def.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Task type "
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		scrollPane.setViewportView(tbl_def);
		
		loadDefaultDefin();
		
		
		
		  
		
		JButton btn_registertype = new JButton("Register task type");
		btn_registertype.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Boolean FoundDup = false;
				for(int i = 0;i<tbl_def.getRowCount();i++) {
					if(tbl_def.getModel().getValueAt(i, 0).equals(txt_regtype.getText()))
						FoundDup = true;
				}
				
				if(FoundDup == false) {
				Main.TaskTypesDefinitions.add(txt_regtype.getText());
				Object[] s = {txt_regtype.getText()};
				DefaultTableModel model = (DefaultTableModel)tbl_def.getModel();
				model.addRow(s);
				}
			}
		});
		btn_registertype.setBounds(211, 22, 156, 23);
		frmDefineTaskTypes.getContentPane().add(btn_registertype);
		
		txt_regtype = new JTextField();
		txt_regtype.setBounds(21, 23, 156, 20);
		frmDefineTaskTypes.getContentPane().add(txt_regtype);
		txt_regtype.setColumns(10);
		
		JButton btn_removedef = new JButton("Remove");
		btn_removedef.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(tbl_def.getSelectedRow() != -1) {
					
					DefaultTableModel model = (DefaultTableModel)tbl_def.getModel();
					Main.TaskTypesDefinitions.remove(model.getValueAt(tbl_def.getSelectedRow(), 0));
			        model.removeRow(tbl_def.getSelectedRow());
			       
				}
			}
		});
		btn_removedef.setBounds(211, 58, 89, 23);
		frmDefineTaskTypes.getContentPane().add(btn_removedef);
	}
	

public static void loadDefaultDefin() {
	DefaultTableModel def_model = (DefaultTableModel)tbl_def.getModel();
	
	for(int i = 0 ;i<Main.TaskTypesDefinitions.size();i++) 
	{
		Object[] s = {Main.TaskTypesDefinitions.get(i)};
		def_model.addRow(s);
	}
//	Object[] objArray = w1.TaskTypesDefinitions.toArray();
//	def_model.addRow(objArray);
	
}
}






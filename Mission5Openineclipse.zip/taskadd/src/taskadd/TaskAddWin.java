package taskadd;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.JSlider;
import javax.swing.JComboBox;

public class TaskAddWin {
	
	JFrame frmEnterTaskName;


	/**
	 * Create the application.
	 */
	public TaskAddWin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frmEnterTaskName = new JFrame();
		frmEnterTaskName.setTitle("Enter task");
		frmEnterTaskName.setBounds(100, 100, 404, 353);
		frmEnterTaskName.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		JLabel lbl_type = new JLabel("Task type");
		lbl_type.setBounds(10, 11, 121, 31);
		
		
		JLabel lbl_duration = new JLabel("Duration");
		lbl_duration.setBounds(10, 75, 98, 23);
		
		JLabel lbl_frequency = new JLabel("Frequency");
		lbl_frequency.setBounds(10, 151, 88, 14);
		
		JSpinner spn_duration = new JSpinner();
		spn_duration.setBounds(178, 75, 63, 20);
		spn_duration.setModel(new SpinnerNumberModel(new Integer(0), new Integer(0), null, new Integer(1)));
		
		JLabel lbl_minutes = new JLabel("Minutes");
		lbl_minutes.setBounds(183, 83, 37, 14);
		
		JSpinner spn_frequency = new JSpinner();
		spn_frequency.setModel(new SpinnerNumberModel(new Integer(0), new Integer(0), null, new Integer(1)));
		spn_frequency.setBounds(178, 143, 63, 20);
		
		JLabel lbl_importance = new JLabel("Importance");
		lbl_importance.setBounds(10, 207, 88, 14);
		
		//populate combobox with arrayslist from MainWin
		//make sure duplicate task dont appear in dropdown e.g ones which are already in task table
		String[] dropdown_copy = Main.TaskTypesDefinitions.toArray(new String[Main.TaskTypesDefinitions.size()]);
		List<String> dropdown_nodups = Main.TaskTypesDefinitions;
		
		for(int i = 0;i<Main.table.getRowCount();i++) {
			dropdown_nodups.remove(Main.table.getModel().getValueAt(i, 0));
		}
		
		
		String[] dropdown_nodups_arr = dropdown_nodups.toArray(new String[dropdown_nodups.size()]);
		JComboBox txt_type = new JComboBox(dropdown_nodups_arr);
		txt_type.setBounds(178, 15, 121, 22);
		
		
		
		JSlider slider_importance = new JSlider();
		slider_importance.setBounds(178, 202, 200, 50);
		slider_importance.setPaintLabels(true);
		slider_importance.setToolTipText("a");
		slider_importance.setMinorTickSpacing(1);
		slider_importance.setMajorTickSpacing(1);
		slider_importance.setMinimum(1);
		slider_importance.setPaintTicks(true);
		slider_importance.setValue(1);
		slider_importance.setMaximum(10);
		
		
		
		JButton btnNewButton = new JButton("Add task");
		btnNewButton.setBounds(85, 269, 156, 23);
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String type = (String) txt_type.getSelectedItem();
				int duration = (int) spn_duration.getValue();
				int frequency = (int)spn_frequency.getValue();
				int importance = (int)slider_importance.getValue();
				
				Object[]row = {type, frequency, importance, duration};
				
				Main.AddTask(row);
				frmEnterTaskName.dispose();
			}
		});
		
		
		
		frmEnterTaskName.getContentPane().setLayout(null);
		frmEnterTaskName.getContentPane().add(btnNewButton);
		frmEnterTaskName.getContentPane().add(lbl_duration);
		frmEnterTaskName.getContentPane().add(lbl_type);
		frmEnterTaskName.getContentPane().add(lbl_frequency);
		frmEnterTaskName.getContentPane().add(lbl_importance);
		frmEnterTaskName.getContentPane().add(slider_importance);
		frmEnterTaskName.getContentPane().add(spn_frequency);
		frmEnterTaskName.getContentPane().add(spn_duration);
		frmEnterTaskName.getContentPane().add(lbl_minutes);
		
		
		frmEnterTaskName.getContentPane().add(txt_type);
	}
}
